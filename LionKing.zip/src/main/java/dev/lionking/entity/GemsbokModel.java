package dev.lionking.entity;

import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

// Modell automatisch aus dem alten 1.4.2-Modell (LKModelGemsbok) uebernommen.
public class GemsbokModel extends EntityModel<LKAnimal> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "gemsbok"), "main");
	private final ModelPart root;
	private final ModelPart head;
	private final ModelPart tail;
	private final ModelPart earLeft;
	private final ModelPart earRight;
	private final ModelPart neck;
	private final ModelPart body;
	private final ModelPart leg1;
	private final ModelPart leg2;
	private final ModelPart leg3;
	private final ModelPart leg4;
	private final ModelPart leftHorn;
	private final ModelPart rightHorn;

	public GemsbokModel(ModelPart root) {
		this.root = root;
		this.head = root.getChild("head");
		this.tail = root.getChild("tail");
		this.earLeft = root.getChild("earLeft");
		this.earRight = root.getChild("earRight");
		this.neck = root.getChild("neck");
		this.body = root.getChild("body");
		this.leg1 = root.getChild("leg1");
		this.leg2 = root.getChild("leg2");
		this.leg3 = root.getChild("leg3");
		this.leg4 = root.getChild("leg4");
		this.leftHorn = root.getChild("leftHorn");
		this.rightHorn = root.getChild("rightHorn");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(28, 0).addBox(-3.0F, -10.0F, -6.0F, 6.0F, 7.0F, 12.0F), PartPose.offset(0.0F, 4.0F, -9.0F));
		root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, 0.0F, 0.0F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(-1.0F, 3.0F, 11.0F, 0.2967059F, 0.0F, 0.0F));
		root.addOrReplaceChild("earLeft", CubeListBuilder.create().texOffs(28, 19).addBox(-3.8F, -12.0F, 3.0F, 1.0F, 3.0F, 2.0F), PartPose.offset(0.0F, 4.0F, -9.0F));
		root.addOrReplaceChild("earRight", CubeListBuilder.create().texOffs(34, 19).addBox(2.8F, -12.0F, 3.0F, 1.0F, 3.0F, 2.0F), PartPose.offset(0.0F, 4.0F, -9.0F));
		root.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(0, 14).addBox(-2.5F, -6.0F, -5.0F, 5.0F, 8.0F, 9.0F), PartPose.offsetAndRotation(0.0F, 4.0F, -9.0F, -1.06465F, 0.0F, 0.0F));
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 31).addBox(-7.0F, -10.0F, -7.0F, 13.0F, 10.0F, 23.0F), PartPose.offset(0.5F, 12.0F, -3.0F));
		root.addOrReplaceChild("leg1", CubeListBuilder.create().texOffs(0, 38).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(-4.0F, 12.0F, 10.0F));
		root.addOrReplaceChild("leg2", CubeListBuilder.create().texOffs(0, 38).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(4.0F, 12.0F, 10.0F));
		root.addOrReplaceChild("leg3", CubeListBuilder.create().texOffs(0, 38).addBox(-2.0F, 0.0F, -3.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(-4.0F, 12.0F, -7.0F));
		root.addOrReplaceChild("leg4", CubeListBuilder.create().texOffs(0, 38).addBox(-2.0F, 0.0F, -3.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(4.0F, 12.0F, -7.0F));
		root.addOrReplaceChild("leftHorn", CubeListBuilder.create().texOffs(0, 0).addBox(-2.8F, -9.5F, 5.8F, 1.0F, 1.0F, 13.0F), PartPose.offset(0.0F, 4.0F, -9.0F));
		root.addOrReplaceChild("rightHorn", CubeListBuilder.create().texOffs(0, 0).addBox(1.8F, -9.5F, 5.8F, 1.0F, 1.0F, 13.0F), PartPose.offset(0.0F, 4.0F, -9.0F));
		return LayerDefinition.create(mesh, 128, 64);
	}

	@Override
	public void setupAnim(LKAnimal entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.head.xRot = headPitch * Mth.DEG_TO_RAD + 0.4014257F;
		this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
		this.neck.yRot = this.head.yRot;
		this.rightHorn.xRot = this.head.xRot;
		this.rightHorn.yRot = this.head.yRot;
		this.leftHorn.xRot = this.head.xRot;
		this.leftHorn.yRot = this.head.yRot;
		this.earLeft.xRot = this.head.xRot;
		this.earLeft.yRot = this.head.yRot;
		this.earRight.xRot = this.head.xRot;
		this.earRight.yRot = this.head.yRot;
		this.leg1.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.leg2.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.leg3.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.leg4.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
		root.render(poseStack, buffer, packedLight, packedOverlay, color);
	}
}
