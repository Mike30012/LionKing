package dev.lionking.entity;

import dev.lionking.LionKingMod;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

@EventBusSubscriber(modid = LionKingMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class LKEvents {
	@SubscribeEvent
	public static void attributes(EntityAttributeCreationEvent event) {
		event.put(LKEntities.ZEBRA.get(), Zebra.attrs().build());
		event.put(LKEntities.RHINO.get(), Rhino.attrs().build());
		event.put(LKEntities.GEMSBOK.get(), Gemsbok.attrs().build());
		event.put(LKEntities.GIRAFFE.get(), Giraffe.attrs().build());
	}

	@SubscribeEvent
	public static void spawnRules(RegisterSpawnPlacementsEvent event) {
		event.register(LKEntities.ZEBRA.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Animal.checkAnimalSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKEntities.RHINO.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Animal.checkAnimalSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKEntities.GEMSBOK.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Animal.checkAnimalSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKEntities.GIRAFFE.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Animal.checkAnimalSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
	}
}
