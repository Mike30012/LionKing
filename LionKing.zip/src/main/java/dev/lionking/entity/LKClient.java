package dev.lionking.entity;

import dev.lionking.LionKingMod;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = LionKingMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class LKClient {
	@SubscribeEvent
	public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ZebraModel.LAYER, ZebraModel::createLayer);
		event.registerLayerDefinition(RhinoModel.LAYER, RhinoModel::createLayer);
		event.registerLayerDefinition(GemsbokModel.LAYER, GemsbokModel::createLayer);
		event.registerLayerDefinition(GiraffeModel.LAYER, GiraffeModel::createLayer);
	}

	@SubscribeEvent
	public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(LKEntities.ZEBRA.get(), ctx -> new LKAnimalRenderer(ctx, new ZebraModel(ctx.bakeLayer(ZebraModel.LAYER)), "zebra", 0.6F));
		event.registerEntityRenderer(LKEntities.RHINO.get(), ctx -> new LKAnimalRenderer(ctx, new RhinoModel(ctx.bakeLayer(RhinoModel.LAYER)), "rhino", 0.6F));
		event.registerEntityRenderer(LKEntities.GEMSBOK.get(), ctx -> new LKAnimalRenderer(ctx, new GemsbokModel(ctx.bakeLayer(GemsbokModel.LAYER)), "gemsbok", 0.6F));
		event.registerEntityRenderer(LKEntities.GIRAFFE.get(), ctx -> new LKAnimalRenderer(ctx, new GiraffeModel(ctx.bakeLayer(GiraffeModel.LAYER)), "giraffe", 0.6F));
	}
}
