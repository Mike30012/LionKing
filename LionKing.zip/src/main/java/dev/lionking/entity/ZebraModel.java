package dev.lionking.entity;

import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

// Modell automatisch aus dem alten 1.4.2-Modell (LKModelZebra) uebernommen.
public class ZebraModel extends EntityModel<LKAnimal> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "zebra"), "main");
	private final ModelPart root;
	private final ModelPart neck;
	private final ModelPart body;
	private final ModelPart leg1;
	private final ModelPart leg2;
	private final ModelPart leg3;
	private final ModelPart leg4;
	private final ModelPart head;
	private final ModelPart mane;
	private final ModelPart tail;

	public ZebraModel(ModelPart root) {
		this.root = root;
		this.neck = root.getChild("neck");
		this.body = root.getChild("body");
		this.leg1 = root.getChild("leg1");
		this.leg2 = root.getChild("leg2");
		this.leg3 = root.getChild("leg3");
		this.leg4 = root.getChild("leg4");
		this.head = root.getChild("head");
		this.mane = root.getChild("mane");
		this.tail = root.getChild("tail");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(98, 26).addBox(-5.0F, -4.0F, -6.0F, 6.0F, 8.0F, 9.0F), PartPose.offsetAndRotation(2.0F, 3.0F, -6.0F, -1.064651F, 0.0F, 0.0F));
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 33).addBox(-6.0F, -10.0F, -7.0F, 12.0F, 10.0F, 21.0F), PartPose.offset(0.0F, 12.0F, -1.0F));
		root.addOrReplaceChild("leg1", CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(-3.0F, 12.0F, 10.0F));
		root.addOrReplaceChild("leg2", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(3.0F, 12.0F, 10.0F));
		root.addOrReplaceChild("leg3", CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, 0.0F, -3.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(-3.0F, 12.0F, -5.0F));
		root.addOrReplaceChild("leg4", CubeListBuilder.create().texOffs(0, 16).addBox(-1.0F, 0.0F, -3.0F, 4.0F, 12.0F, 4.0F), PartPose.offset(3.0F, 12.0F, -5.0F));
		root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(84, 0).addBox(0.0F, 0.0F, 0.0F, 8.0F, 8.0F, 14.0F).texOffs(72, 0).addBox(1.0F, -3.0F, 10.0F, 1.0F, 3.0F, 2.0F).texOffs(78, 0).addBox(6.0F, -3.0F, 10.0F, 1.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -3.0F, -19.0F, 0.4014257F, 0.0F, 0.0F));
		root.addOrReplaceChild("mane", CubeListBuilder.create().texOffs(92, 47).addBox(0.0F, 0.0F, 0.0F, 4.0F, 3.0F, 14.0F), PartPose.offsetAndRotation(-2.0F, 5.0F, -1.0F, 2.111848F, 0.0F, 0.0F));
		root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(0, 0).addBox(-1.0F, -4.0F, 13.5F, 2.0F, 12.0F, 2.0F), PartPose.offsetAndRotation(0.0F, 12.0F, -1.0F, 0.296706F, 0.0F, 0.0F));
		return LayerDefinition.create(mesh, 128, 64);
	}

	@Override
	public void setupAnim(LKAnimal entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.leg1.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.leg2.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.leg3.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.leg4.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
		root.render(poseStack, buffer, packedLight, packedOverlay, color);
	}
}
