package dev.lionking.entity;

import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

// Modell automatisch aus dem alten 1.4.2-Modell (LKModelGiraffe) uebernommen.
public class GiraffeModel extends EntityModel<LKAnimal> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "giraffe"), "main");
	private final ModelPart root;
	private final ModelPart body;
	private final ModelPart neck;
	private final ModelPart head;
	private final ModelPart tail;
	private final ModelPart leg1;
	private final ModelPart leg2;
	private final ModelPart leg3;
	private final ModelPart leg4;

	public GiraffeModel(ModelPart root) {
		this.root = root;
		this.body = root.getChild("body");
		this.neck = root.getChild("neck");
		this.head = root.getChild("head");
		this.tail = root.getChild("tail");
		this.leg1 = root.getChild("leg1");
		this.leg2 = root.getChild("leg2");
		this.leg3 = root.getChild("leg3");
		this.leg4 = root.getChild("leg4");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -8.0F, -13.0F, 12.0F, 16.0F, 26.0F), PartPose.offset(0.0F, -11.0F, 0.0F));
		root.addOrReplaceChild("neck", CubeListBuilder.create().texOffs(0, 44).addBox(-4.5F, -13.0F, -4.5F, 9.0F, 11.0F, 9.0F).texOffs(78, 0).addBox(-3.0F, -37.0F, -3.0F, 6.0F, 40.0F, 6.0F), PartPose.offset(0.0F, -14.0F, -7.0F));
		root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(96, 48).addBox(-3.0F, -43.0F, -6.0F, 6.0F, 6.0F, 10.0F).texOffs(10, 0).addBox(-4.0F, -45.0F, 1.5F, 1.0F, 3.0F, 2.0F).texOffs(17, 0).addBox(3.0F, -45.0F, 1.5F, 1.0F, 3.0F, 2.0F).texOffs(0, 0).addBox(-2.5F, -47.0F, 0.0F, 1.0F, 4.0F, 1.0F).texOffs(5, 0).addBox(1.5F, -47.0F, 0.0F, 1.0F, 4.0F, 1.0F).texOffs(76, 56).addBox(-2.0F, -41.0F, -11.0F, 4.0F, 3.0F, 5.0F), PartPose.offset(0.0F, -14.0F, -7.0F));
		root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(104, 0).addBox(-0.5F, 0.0F, 0.0F, 1.0F, 24.0F, 1.0F), PartPose.offset(0.0F, -12.0F, 13.0F));
		root.addOrReplaceChild("leg1", CubeListBuilder.create().texOffs(112, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 27.0F, 4.0F), PartPose.offset(-3.9F, -3.0F, 8.0F));
		root.addOrReplaceChild("leg2", CubeListBuilder.create().texOffs(112, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 27.0F, 4.0F), PartPose.offset(3.9F, -3.0F, 8.0F));
		root.addOrReplaceChild("leg3", CubeListBuilder.create().texOffs(112, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 27.0F, 4.0F), PartPose.offset(-3.9F, -3.0F, -7.0F));
		root.addOrReplaceChild("leg4", CubeListBuilder.create().texOffs(112, 0).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 27.0F, 4.0F), PartPose.offset(3.9F, -3.0F, -7.0F));
		return LayerDefinition.create(mesh, 128, 64);
	}

	@Override
	public void setupAnim(LKAnimal entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.head.xRot = headPitch * Mth.DEG_TO_RAD + 0.17453294F;
		this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
		this.neck.xRot = headPitch * Mth.DEG_TO_RAD + 0.17453294F;
		this.neck.yRot = netHeadYaw * Mth.DEG_TO_RAD;
		this.leg1.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount * 0.5F;
		this.leg2.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount * 0.5F;
		this.leg3.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount * 0.5F;
		this.leg4.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount * 0.5F;
		this.tail.zRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount * 0.2F;
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
		root.render(poseStack, buffer, packedLight, packedOverlay, color);
	}
}
