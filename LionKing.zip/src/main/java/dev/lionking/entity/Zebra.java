package dev.lionking.entity;

import dev.lionking.LionKingMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;

public class Zebra extends LKAnimal {
	public Zebra(EntityType<? extends Zebra> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder attrs() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 12.0F)
				.add(Attributes.MOVEMENT_SPEED, 0.2F);
	}

	@Override
	protected Ingredient foodIngredient() {
		return Ingredient.of(Items.WHEAT, LionKingMod.CORN.get());
	}

	@Override
	public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) {
		return LKEntities.ZEBRA.get().create(level);
	}
}
