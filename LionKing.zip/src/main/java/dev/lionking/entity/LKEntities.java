package dev.lionking.entity;

import dev.lionking.LionKingMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class LKEntities {
	public static final DeferredRegister<EntityType<?>> TYPES = DeferredRegister.create(Registries.ENTITY_TYPE, LionKingMod.MODID);
	public static final DeferredRegister.Items EGGS = DeferredRegister.createItems(LionKingMod.MODID);

	public static final DeferredHolder<EntityType<?>, EntityType<Zebra>> ZEBRA = TYPES.register("zebra", () -> EntityType.Builder.of(Zebra::new, MobCategory.CREATURE).sized(1.1F, 1.4F).clientTrackingRange(10).build("zebra"));
	public static final DeferredHolder<EntityType<?>, EntityType<Rhino>> RHINO = TYPES.register("rhino", () -> EntityType.Builder.of(Rhino::new, MobCategory.CREATURE).sized(1.4F, 1.2F).clientTrackingRange(10).build("rhino"));
	public static final DeferredHolder<EntityType<?>, EntityType<Gemsbok>> GEMSBOK = TYPES.register("gemsbok", () -> EntityType.Builder.of(Gemsbok::new, MobCategory.CREATURE).sized(0.9F, 1.4F).clientTrackingRange(10).build("gemsbok"));
	public static final DeferredHolder<EntityType<?>, EntityType<Giraffe>> GIRAFFE = TYPES.register("giraffe", () -> EntityType.Builder.of(Giraffe::new, MobCategory.CREATURE).sized(1.7F, 2.8F).clientTrackingRange(10).build("giraffe"));

	public static final DeferredItem<Item> ZEBRA_EGG = EGGS.register("zebra_spawn_egg", () -> new DeferredSpawnEggItem(ZEBRA, 0x2b2b2b, 0xf0f0f0, new Item.Properties()));
	public static final DeferredItem<Item> RHINO_EGG = EGGS.register("rhino_spawn_egg", () -> new DeferredSpawnEggItem(RHINO, 0x7d7d80, 0x4a4a4c, new Item.Properties()));
	public static final DeferredItem<Item> GEMSBOK_EGG = EGGS.register("gemsbok_spawn_egg", () -> new DeferredSpawnEggItem(GEMSBOK, 0xc9a37a, 0x3b2a1c, new Item.Properties()));
	public static final DeferredItem<Item> GIRAFFE_EGG = EGGS.register("giraffe_spawn_egg", () -> new DeferredSpawnEggItem(GIRAFFE, 0xe0b040, 0x6b4a1e, new Item.Properties()));

	public static void register(IEventBus modBus) {
		TYPES.register(modBus);
		EGGS.register(modBus);
	}
}
