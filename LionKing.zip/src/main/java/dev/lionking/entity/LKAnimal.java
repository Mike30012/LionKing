package dev.lionking.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

// Gemeinsames Verhalten der Savannentiere (wie die alte LKEntityQuestAnimal / Kuh-KI).
public abstract class LKAnimal extends Animal {
	protected LKAnimal(EntityType<? extends LKAnimal> type, Level level) {
		super(type, level);
	}

	protected abstract Ingredient foodIngredient();

	@Override
	protected void registerGoals() {
		goalSelector.addGoal(0, new FloatGoal(this));
		goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
		goalSelector.addGoal(2, new BreedGoal(this, 1.0D));
		goalSelector.addGoal(3, new TemptGoal(this, 1.2D, foodIngredient(), false));
		goalSelector.addGoal(4, new FollowParentGoal(this, 1.1D));
		goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0D));
		goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
		goalSelector.addGoal(7, new RandomLookAroundGoal(this));
	}

	@Override
	public boolean isFood(ItemStack stack) {
		return foodIngredient().test(stack);
	}

	@Override
	protected SoundEvent getAmbientSound() { return SoundEvents.COW_AMBIENT; }

	@Override
	protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.COW_HURT; }

	@Override
	protected SoundEvent getDeathSound() { return SoundEvents.COW_DEATH; }

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		playSound(SoundEvents.COW_STEP, 0.15F, 1.0F);
	}

	@Override
	protected float getSoundVolume() { return 0.4F; }
}
