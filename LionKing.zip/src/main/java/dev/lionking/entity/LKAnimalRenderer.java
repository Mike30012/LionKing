package dev.lionking.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class LKAnimalRenderer extends MobRenderer<LKAnimal, EntityModel<LKAnimal>> {
	private final ResourceLocation texture;

	public LKAnimalRenderer(EntityRendererProvider.Context ctx, EntityModel<LKAnimal> model, String name, float shadow) {
		super(ctx, model, shadow);
		this.texture = ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "textures/entity/" + name + ".png");
	}

	@Override
	public ResourceLocation getTextureLocation(LKAnimal entity) {
		return texture;
	}

	@Override
	protected void scale(LKAnimal entity, PoseStack poseStack, float partialTick) {
		if (entity.isBaby()) {
			poseStack.scale(0.5F, 0.5F, 0.5F);
		}
	}
}
