package dev.lionking.mob;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class Pumbaa extends LKNpc {
	public Pumbaa(EntityType<? extends Pumbaa> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder attrs() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 100.0F)
				.add(Attributes.MOVEMENT_SPEED, 0.21F);
	}

	private static final String[] LINES = {
			"§e<Timon> §fYou look down. Can we help?",
			"§e<Pumbaa> §fWhat's that you say? Outlanders have taken over Rafiki's tree?",
			"§e<Timon> §fOutlanders? Man, I hate Outlanders. Almost as much as I hate hyenas, and I HATE hyenas.",
			"§e<Timon> §fHold on! I just had a great idea! Pumbaa here could - er, pass gas, and those Outlanders would move out of that tree faster than a wildebeest stampede!"
	};

	@Override
	protected String[] lines() { return LINES; }
}
