package dev.lionking.mob;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class Zazu extends LKNpc {
	public Zazu(EntityType<? extends Zazu> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder attrs() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 8.0F)
				.add(Attributes.MOVEMENT_SPEED, 0.25F);
	}
}
