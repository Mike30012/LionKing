package dev.lionking.mob;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

// Modell automatisch aus dem alten 1.4.2-Modell (LKModelPumbaa) uebernommen.
public class PumbaaModel extends EntityModel<Mob> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "pumbaa"), "main");
	private final ModelPart root;
	private final ModelPart snout;
	private final ModelPart leftear;
	private final ModelPart rightear;
	private final ModelPart tail;
	private final ModelPart mane;
	private final ModelPart hair;
	private final ModelPart lefthorn;
	private final ModelPart righthorn;
	private final ModelPart head;
	private final ModelPart body;
	private final ModelPart leg1;
	private final ModelPart leg2;
	private final ModelPart leg3;
	private final ModelPart leg4;

	public PumbaaModel(ModelPart root) {
		this.root = root;
		this.snout = root.getChild("snout");
		this.leftear = root.getChild("leftear");
		this.rightear = root.getChild("rightear");
		this.tail = root.getChild("tail");
		this.mane = root.getChild("mane");
		this.hair = root.getChild("hair");
		this.lefthorn = root.getChild("lefthorn");
		this.righthorn = root.getChild("righthorn");
		this.head = root.getChild("head");
		this.body = root.getChild("body");
		this.leg1 = root.getChild("leg1");
		this.leg2 = root.getChild("leg2");
		this.leg3 = root.getChild("leg3");
		this.leg4 = root.getChild("leg4");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("snout", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -2.6F, -11.0F, 6.0F, 4.0F, 3.0F), PartPose.offset(0.0F, 9.0F, -5.0F));
		root.addOrReplaceChild("leftear", CubeListBuilder.create().texOffs(0, 31).addBox(-3.5F, -9.0F, -3.0F, 1.0F, 4.0F, 2.0F), PartPose.offset(0.0F, 9.0F, -5.0F));
		root.addOrReplaceChild("rightear", CubeListBuilder.create().texOffs(6, 31).addBox(3.5F, -9.0F, -3.0F, 1.0F, 4.0F, 2.0F), PartPose.offset(0.0F, 9.0F, -5.0F));
		root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(60, 55).addBox(-0.5F, -1.5F, 1.0F, 1.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 11.0F, 8.0F, 0.698132F, 0.0F, 0.0F));
		root.addOrReplaceChild("mane", CubeListBuilder.create().texOffs(36, 18).addBox(-3.5F, -4.0F, -2.0F, 5.0F, 4.0F, 9.0F), PartPose.offsetAndRotation(1.0F, 9.0F, -7.0F, -0.417716F, 0.0F, 0.0F));
		root.addOrReplaceChild("hair", CubeListBuilder.create().texOffs(0, 10).addBox(-2.0F, -7.3F, -4.7F, 4.0F, 5.0F, 5.0F), PartPose.offset(0.0F, 9.0F, -5.0F));
		root.addOrReplaceChild("lefthorn", CubeListBuilder.create().texOffs(54, 31).addBox(-9.0F, -2.0F, -7.0F, 4.0F, 1.0F, 1.0F), PartPose.offset(0.0F, 9.0F, -5.0F));
		root.addOrReplaceChild("righthorn", CubeListBuilder.create().texOffs(54, 31).addBox(5.0F, -2.0F, -7.0F, 4.0F, 1.0F, 1.0F), PartPose.offset(0.0F, 9.0F, -5.0F));
		root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(28, 0).addBox(-5.0F, -6.0F, -8.0F, 10.0F, 10.0F, 8.0F), PartPose.offset(0.0F, 9.0F, -5.0F));
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 37).addBox(-5.0F, -10.0F, -7.0F, 12.0F, 17.0F, 10.0F), PartPose.offsetAndRotation(-1.0F, 11.0F, 2.0F, 1.570796F, 0.0F, 0.0F));
		root.addOrReplaceChild("leg1", CubeListBuilder.create().texOffs(0, 20).addBox(-2.0F, 0.0F, -2.0F, 3.0F, 8.0F, 3.0F), PartPose.offset(-3.0F, 16.0F, 6.0F));
		root.addOrReplaceChild("leg2", CubeListBuilder.create().texOffs(0, 20).addBox(-1.5F, 0.0F, -2.0F, 3.0F, 8.0F, 3.0F), PartPose.offset(3.0F, 16.0F, 6.0F));
		root.addOrReplaceChild("leg3", CubeListBuilder.create().texOffs(0, 20).addBox(-2.0F, 0.0F, -2.0F, 3.0F, 8.0F, 3.0F), PartPose.offset(-3.0F, 16.0F, -4.0F));
		root.addOrReplaceChild("leg4", CubeListBuilder.create().texOffs(0, 20).addBox(-1.0F, 0.0F, -2.0F, 3.0F, 8.0F, 3.0F), PartPose.offset(3.0F, 16.0F, -4.0F));
		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(Mob entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.head.xRot = headPitch * Mth.DEG_TO_RAD;
		this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
		this.snout.xRot = this.head.xRot;
		this.snout.yRot = this.head.yRot;
		this.leftear.xRot = this.head.xRot;
		this.leftear.yRot = this.head.yRot;
		this.rightear.xRot = this.head.xRot;
		this.rightear.yRot = this.head.yRot;
		this.mane.xRot = this.head.xRot;
		this.mane.yRot = this.head.yRot;
		this.hair.xRot = this.head.xRot;
		this.hair.yRot = this.head.yRot;
		this.lefthorn.xRot = this.head.xRot;
		this.lefthorn.yRot = this.head.yRot;
		this.righthorn.xRot = this.head.xRot;
		this.righthorn.yRot = this.head.yRot;
		this.leg1.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.leg2.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.leg3.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.leg4.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
		root.render(poseStack, buffer, packedLight, packedOverlay, color);
	}
}
