package dev.lionking.mob;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

// Modell automatisch aus dem alten 1.4.2-Modell (LKModelCrocodile) uebernommen.
public class CrocodileModel extends EntityModel<Mob> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "crocodile"), "main");
	private final ModelPart root;
	private final ModelPart body;
	private final ModelPart tail1;
	private final ModelPart tail2;
	private final ModelPart tail3;
	private final ModelPart jaw;
	private final ModelPart head;
	private final ModelPart legFrontLeft;
	private final ModelPart legBackLeft;
	private final ModelPart legFrontRight;
	private final ModelPart legBackRight;
	private final ModelPart spines;

	public CrocodileModel(ModelPart root) {
		this.root = root;
		this.body = root.getChild("body");
		this.tail1 = root.getChild("tail1");
		this.tail2 = root.getChild("tail2");
		this.tail3 = root.getChild("tail3");
		this.jaw = root.getChild("jaw");
		this.head = root.getChild("head");
		this.legFrontLeft = root.getChild("legFrontLeft");
		this.legBackLeft = root.getChild("legBackLeft");
		this.legFrontRight = root.getChild("legFrontRight");
		this.legBackRight = root.getChild("legBackRight");
		this.spines = root.getChild("spines");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(18, 83).addBox(-8.0F, -5.0F, 0.0F, 16.0F, 9.0F, 36.0F), PartPose.offset(0.0F, 17.0F, -16.0F));
		root.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(0, 28).addBox(-7.0F, 0.0F, 0.0F, 14.0F, 7.0F, 19.0F), PartPose.offset(0.0F, 13.0F, 18.0F));
		root.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(0, 55).addBox(-6.0F, 1.5F, 17.0F, 12.0F, 5.0F, 16.0F), PartPose.offset(0.0F, 13.0F, 18.0F));
		root.addOrReplaceChild("tail3", CubeListBuilder.create().texOffs(0, 77).addBox(-5.0F, 3.0F, 31.0F, 10.0F, 3.0F, 14.0F), PartPose.offset(0.0F, 13.0F, 18.0F));
		root.addOrReplaceChild("jaw", CubeListBuilder.create().texOffs(58, 18).addBox(-6.5F, 0.3F, -19.0F, 13.0F, 4.0F, 19.0F), PartPose.offset(0.0F, 17.0F, -16.0F));
		root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-7.5F, -6.0F, -21.0F, 15.0F, 6.0F, 21.0F), PartPose.offset(0.0F, 18.5F, -16.0F));
		root.addOrReplaceChild("legFrontLeft", CubeListBuilder.create().texOffs(2, 104).addBox(0.0F, 0.0F, -3.0F, 16.0F, 3.0F, 6.0F), PartPose.offsetAndRotation(6.0F, 15.0F, -11.0F, 0.0F, 0.0F, 0.43633232F));
		root.addOrReplaceChild("legBackLeft", CubeListBuilder.create().texOffs(2, 104).addBox(0.0F, 0.0F, -3.0F, 16.0F, 3.0F, 6.0F), PartPose.offsetAndRotation(6.0F, 15.0F, 15.0F, 0.0F, 0.0F, 0.43633232F));
		root.addOrReplaceChild("legFrontRight", CubeListBuilder.create().texOffs(2, 104).addBox(-16.0F, 0.0F, -3.0F, 16.0F, 3.0F, 6.0F), PartPose.offsetAndRotation(-6.0F, 15.0F, -11.0F, 0.0F, 0.0F, -0.43633232F));
		root.addOrReplaceChild("legBackRight", CubeListBuilder.create().texOffs(2, 104).addBox(-16.0F, 0.0F, -3.0F, 16.0F, 3.0F, 6.0F), PartPose.offsetAndRotation(-6.0F, 15.0F, 15.0F, 0.0F, 0.0F, -0.43633232F));
		root.addOrReplaceChild("spines", CubeListBuilder.create().texOffs(46, 45).addBox(-5.0F, 0.0F, 0.0F, 10.0F, 4.0F, 32.0F), PartPose.offsetAndRotation(0.0F, 9.5F, -14.0F, -0.034906585F, 0.0F, 0.0F));
		return LayerDefinition.create(mesh, 128, 128);
	}

	@Override
	public void setupAnim(Mob entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.head.xRot = headPitch * Mth.DEG_TO_RAD;
		this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
		this.tail1.yRot = Mth.cos(ageInTicks * 0.1F + 1.0F) * 0.1F;
		this.tail2.yRot = Mth.cos(ageInTicks * 0.1F + 2.0F) * 0.1F;
		this.tail3.yRot = Mth.cos(ageInTicks * 0.1F + 3.0F) * 0.1F;
		this.jaw.xRot = Mth.sin(ageInTicks * 0.05F) * 0.03F;
		this.legFrontLeft.xRot = Mth.cos(limbSwing * 0.6662F) * 1.0F * limbSwingAmount;
		this.legBackLeft.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.0F * limbSwingAmount;
		this.legFrontRight.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.0F * limbSwingAmount;
		this.legBackRight.xRot = Mth.cos(limbSwing * 0.6662F) * 1.0F * limbSwingAmount;
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
		root.render(poseStack, buffer, packedLight, packedOverlay, color);
	}
}
