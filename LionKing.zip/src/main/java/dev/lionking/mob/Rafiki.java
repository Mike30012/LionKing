package dev.lionking.mob;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class Rafiki extends LKNpc {
	public Rafiki(EntityType<? extends Rafiki> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder attrs() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 100.0F)
				.add(Attributes.MOVEMENT_SPEED, 0.35F);
	}

	private static final String[] LINES = {
			"§e<Rafiki> §fThis portal will take you to the Outlands. I want you to go there, collect four termites, and grind them up.",
			"§e<Rafiki> §fMay Mufasa guide you in that dreadful place...",
			"§e<Rafiki> §fI have long known that the great kings of the past are up there in the stars, watching over us.",
			"§e<Rafiki> §fBut it is only recently that I have discovered a way to bring them back to the Pride Lands.",
			"§e<Rafiki> §fWith the materials you have given me, I can create a dust so magical that you can use it to undo Scar's work and return our king from the stars!",
			"§e<Rafiki> §fOhoho! Old Rafiki was never gone for good! But you've kicked up quite a stink here, haven't you?",
			"§e<Rafiki> §fNow's your chance to put things right. Go through that portal and put an end to Zira's outlandish scheme!"
	};

	@Override
	protected String[] lines() { return LINES; }
}
