package dev.lionking.mob;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

// Freundliche Figuren (Simba, Rafiki, Timon, Pumbaa, Zazu). Rechtsklick spielt die Dialogzeilen der Reihe nach ab.
public abstract class LKNpc extends PathfinderMob {
	private int lineIndex = 0;

	protected LKNpc(EntityType<? extends LKNpc> type, Level level) {
		super(type, level);
	}

	protected String[] lines() { return new String[0]; }

	@Override
	protected void registerGoals() {
		goalSelector.addGoal(0, new FloatGoal(this));
		goalSelector.addGoal(1, new PanicGoal(this, 1.3D));
		goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6D));
		goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
		goalSelector.addGoal(7, new RandomLookAroundGoal(this));
	}

	@Override
	public boolean removeWhenFarAway(double distance) {
		return false;
	}

	@Override
	protected InteractionResult mobInteract(Player player, InteractionHand hand) {
		String[] l = lines();
		if (l.length == 0) {
			return super.mobInteract(player, hand);
		}
		if (!level().isClientSide) {
			player.sendSystemMessage(Component.literal(l[lineIndex % l.length]));
			lineIndex++;
		}
		return InteractionResult.sidedSuccess(level().isClientSide);
	}
}
