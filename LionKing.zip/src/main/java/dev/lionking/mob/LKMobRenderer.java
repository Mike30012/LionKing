package dev.lionking.mob;

import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

public class LKMobRenderer extends MobRenderer<Mob, EntityModel<Mob>> {
	private final ResourceLocation texture;

	public LKMobRenderer(EntityRendererProvider.Context ctx, EntityModel<Mob> model, String name, float shadow) {
		super(ctx, model, shadow);
		this.texture = ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "textures/entity/" + name + ".png");
	}

	@Override
	public ResourceLocation getTextureLocation(Mob entity) {
		return texture;
	}
}
