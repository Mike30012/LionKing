package dev.lionking.mob;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

// Modell automatisch aus dem alten 1.4.2-Modell (LKModelTimon) uebernommen.
public class TimonModel extends EntityModel<Mob> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "timon"), "main");
	private final ModelPart root;
	private final ModelPart head;
	private final ModelPart body;
	private final ModelPart rightarm;
	private final ModelPart leftarm;
	private final ModelPart rightleg;
	private final ModelPart leftleg;
	private final ModelPart tail;
	private final ModelPart leftear;
	private final ModelPart rightear;

	public TimonModel(ModelPart root) {
		this.root = root;
		this.head = root.getChild("head");
		this.body = root.getChild("body");
		this.rightarm = root.getChild("rightarm");
		this.leftarm = root.getChild("leftarm");
		this.rightleg = root.getChild("rightleg");
		this.leftleg = root.getChild("leftleg");
		this.tail = root.getChild("tail");
		this.leftear = root.getChild("leftear");
		this.rightear = root.getChild("rightear");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 7.0F, 6.0F).texOffs(46, 7).addBox(-3.5F, -9.0F, -2.0F, 7.0F, 1.0F, 2.0F).texOffs(0, 0).addBox(-1.0F, -5.0F, -5.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(0.0F, 1.0F, 1.0F));
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(40, 12).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 15.0F, 4.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
		root.addOrReplaceChild("rightarm", CubeListBuilder.create().texOffs(20, 13).addBox(-3.0F, -2.0F, -2.0F, 3.0F, 12.0F, 3.0F), PartPose.offset(-4.0F, 3.0F, 0.5F));
		root.addOrReplaceChild("leftarm", CubeListBuilder.create().texOffs(20, 13).addBox(-1.0F, -2.0F, -2.0F, 3.0F, 12.0F, 3.0F), PartPose.offset(5.0F, 3.0F, 0.5F));
		root.addOrReplaceChild("rightleg", CubeListBuilder.create().texOffs(0, 13).addBox(-2.0F, 0.0F, -2.0F, 3.0F, 9.0F, 3.0F).texOffs(44, 0).addBox(-2.7F, 8.0F, -3.9F, 4.0F, 1.0F, 6.0F), PartPose.offset(-1.7F, 15.0F, 0.5F));
		root.addOrReplaceChild("leftleg", CubeListBuilder.create().texOffs(0, 13).addBox(-2.0F, 0.0F, -2.0F, 3.0F, 9.0F, 3.0F).texOffs(44, 0).addBox(-2.3F, 8.0F, -3.9F, 4.0F, 1.0F, 6.0F), PartPose.offset(2.7F, 15.0F, 0.5F));
		root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(0, 13).addBox(-1.0F, 0.0F, 0.0F, 2.0F, 2.0F, 16.0F), PartPose.offset(0.0F, 9.0F, 1.0F));
		root.addOrReplaceChild("leftear", CubeListBuilder.create().texOffs(36, 0).addBox(-7.0F, -5.0F, -1.5F, 3.0F, 5.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 1.0F, 1.0F, 0.0F, 0.0F, 0.38397F));
		root.addOrReplaceChild("rightear", CubeListBuilder.create().texOffs(36, 0).addBox(4.0F, -5.0F, -1.5F, 3.0F, 5.0F, 1.0F), PartPose.offsetAndRotation(0.0F, 1.0F, 1.0F, 0.0F, 0.0F, -0.38397F));
		return LayerDefinition.create(mesh, 64, 32);
	}

	@Override
	public void setupAnim(Mob entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.head.xRot = headPitch * Mth.DEG_TO_RAD;
		this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
		this.leftear.xRot = this.head.xRot;
		this.leftear.yRot = this.head.yRot;
		this.rightear.xRot = this.head.xRot;
		this.rightear.yRot = this.head.yRot;
		this.rightarm.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.leftarm.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.rightleg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.leftleg.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
		root.render(poseStack, buffer, packedLight, packedOverlay, color);
	}
}
