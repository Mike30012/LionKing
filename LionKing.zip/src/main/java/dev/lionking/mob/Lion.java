package dev.lionking.mob;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class Lion extends LKFighter {
	public Lion(EntityType<? extends Lion> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder attrs() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 18.0F)
				.add(Attributes.MOVEMENT_SPEED, 0.31F)
				.add(Attributes.ATTACK_DAMAGE, 4.0F)
				.add(Attributes.FOLLOW_RANGE, 24.0D);
	}

	@Override
	protected boolean hostileToPlayers() { return false; }
}
