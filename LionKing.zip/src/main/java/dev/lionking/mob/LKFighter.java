package dev.lionking.mob;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

// Raubtiere: Hyaenen, Loewen, Krokodil, Geier, Scar, Zira
public abstract class LKFighter extends PathfinderMob {
	protected LKFighter(EntityType<? extends LKFighter> type, Level level) {
		super(type, level);
	}

	protected abstract boolean hostileToPlayers();

	protected boolean persistent() { return false; }

	@Override
	protected void registerGoals() {
		goalSelector.addGoal(0, new FloatGoal(this));
		goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.1D, false));
		goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
		goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
		goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		targetSelector.addGoal(1, new HurtByTargetGoal(this));
		if (hostileToPlayers()) {
			targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
		}
	}

	@Override
	public boolean removeWhenFarAway(double distance) {
		return !persistent();
	}

	@Override
	protected SoundEvent getAmbientSound() { return SoundEvents.WOLF_GROWL; }

	@Override
	protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.WOLF_HURT; }

	@Override
	protected SoundEvent getDeathSound() { return SoundEvents.WOLF_DEATH; }
}
