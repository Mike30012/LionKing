package dev.lionking.mob;

import dev.lionking.LionKingMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class LKMobs {
	public static final DeferredRegister<EntityType<?>> TYPES = DeferredRegister.create(Registries.ENTITY_TYPE, LionKingMod.MODID);
	public static final DeferredRegister.Items EGGS = DeferredRegister.createItems(LionKingMod.MODID);

	public static final DeferredHolder<EntityType<?>, EntityType<Hyena>> HYENA = TYPES.register("hyena", () -> EntityType.Builder.of(Hyena::new, MobCategory.MONSTER).sized(0.8F, 0.8F).clientTrackingRange(10).build("hyena"));
	public static final DeferredHolder<EntityType<?>, EntityType<Crocodile>> CROCODILE = TYPES.register("crocodile", () -> EntityType.Builder.of(Crocodile::new, MobCategory.MONSTER).sized(1.7F, 0.57F).clientTrackingRange(10).build("crocodile"));
	public static final DeferredHolder<EntityType<?>, EntityType<Vulture>> VULTURE = TYPES.register("vulture", () -> EntityType.Builder.of(Vulture::new, MobCategory.MONSTER).sized(0.8F, 1.5F).clientTrackingRange(10).build("vulture"));
	public static final DeferredHolder<EntityType<?>, EntityType<Lion>> LION = TYPES.register("lion", () -> EntityType.Builder.of(Lion::new, MobCategory.CREATURE).sized(1.3F, 1.6F).clientTrackingRange(10).build("lion"));
	public static final DeferredHolder<EntityType<?>, EntityType<Lioness>> LIONESS = TYPES.register("lioness", () -> EntityType.Builder.of(Lioness::new, MobCategory.CREATURE).sized(1.2F, 1.3F).clientTrackingRange(10).build("lioness"));
	public static final DeferredHolder<EntityType<?>, EntityType<Scar>> SCAR = TYPES.register("scar", () -> EntityType.Builder.of(Scar::new, MobCategory.MONSTER).sized(1.3F, 1.6F).clientTrackingRange(10).build("scar"));
	public static final DeferredHolder<EntityType<?>, EntityType<Zira>> ZIRA = TYPES.register("zira", () -> EntityType.Builder.of(Zira::new, MobCategory.MONSTER).sized(1.3F, 1.6F).clientTrackingRange(10).build("zira"));
	public static final DeferredHolder<EntityType<?>, EntityType<Simba>> SIMBA = TYPES.register("simba", () -> EntityType.Builder.of(Simba::new, MobCategory.CREATURE).sized(1.3F, 1.6F).clientTrackingRange(10).build("simba"));
	public static final DeferredHolder<EntityType<?>, EntityType<Rafiki>> RAFIKI = TYPES.register("rafiki", () -> EntityType.Builder.of(Rafiki::new, MobCategory.CREATURE).sized(0.7F, 1.6F).clientTrackingRange(10).build("rafiki"));
	public static final DeferredHolder<EntityType<?>, EntityType<Timon>> TIMON = TYPES.register("timon", () -> EntityType.Builder.of(Timon::new, MobCategory.CREATURE).sized(0.4F, 0.9F).clientTrackingRange(10).build("timon"));
	public static final DeferredHolder<EntityType<?>, EntityType<Pumbaa>> PUMBAA = TYPES.register("pumbaa", () -> EntityType.Builder.of(Pumbaa::new, MobCategory.CREATURE).sized(1.2F, 1.3F).clientTrackingRange(10).build("pumbaa"));
	public static final DeferredHolder<EntityType<?>, EntityType<Zazu>> ZAZU = TYPES.register("zazu", () -> EntityType.Builder.of(Zazu::new, MobCategory.CREATURE).sized(0.6F, 0.8F).clientTrackingRange(10).build("zazu"));

	public static final DeferredItem<Item> HYENA_EGG = EGGS.register("hyena_spawn_egg", () -> new DeferredSpawnEggItem(HYENA, 0x8a7a50, 0x3a2a1a, new Item.Properties()));
	public static final DeferredItem<Item> CROCODILE_EGG = EGGS.register("crocodile_spawn_egg", () -> new DeferredSpawnEggItem(CROCODILE, 0x4f6b3a, 0xd8d09a, new Item.Properties()));
	public static final DeferredItem<Item> VULTURE_EGG = EGGS.register("vulture_spawn_egg", () -> new DeferredSpawnEggItem(VULTURE, 0x3a2a22, 0xc04040, new Item.Properties()));
	public static final DeferredItem<Item> LION_EGG = EGGS.register("lion_spawn_egg", () -> new DeferredSpawnEggItem(LION, 0xc99a4a, 0x6b3a1a, new Item.Properties()));
	public static final DeferredItem<Item> LIONESS_EGG = EGGS.register("lioness_spawn_egg", () -> new DeferredSpawnEggItem(LIONESS, 0xd8b070, 0x8a5a2a, new Item.Properties()));
	public static final DeferredItem<Item> SCAR_EGG = EGGS.register("scar_spawn_egg", () -> new DeferredSpawnEggItem(SCAR, 0x1a1a1a, 0x8a1a1a, new Item.Properties()));
	public static final DeferredItem<Item> ZIRA_EGG = EGGS.register("zira_spawn_egg", () -> new DeferredSpawnEggItem(ZIRA, 0x6a4a3a, 0xa03030, new Item.Properties()));
	public static final DeferredItem<Item> SIMBA_EGG = EGGS.register("simba_spawn_egg", () -> new DeferredSpawnEggItem(SIMBA, 0xe0a040, 0xa02020, new Item.Properties()));
	public static final DeferredItem<Item> RAFIKI_EGG = EGGS.register("rafiki_spawn_egg", () -> new DeferredSpawnEggItem(RAFIKI, 0x7a5a3a, 0xe8e0c8, new Item.Properties()));
	public static final DeferredItem<Item> TIMON_EGG = EGGS.register("timon_spawn_egg", () -> new DeferredSpawnEggItem(TIMON, 0x8a6a3a, 0xe0c890, new Item.Properties()));
	public static final DeferredItem<Item> PUMBAA_EGG = EGGS.register("pumbaa_spawn_egg", () -> new DeferredSpawnEggItem(PUMBAA, 0x5a4a3a, 0xd0b080, new Item.Properties()));
	public static final DeferredItem<Item> ZAZU_EGG = EGGS.register("zazu_spawn_egg", () -> new DeferredSpawnEggItem(ZAZU, 0x4a70b0, 0xe04030, new Item.Properties()));

	public static void register(IEventBus modBus) {
		TYPES.register(modBus);
		EGGS.register(modBus);
	}
}
