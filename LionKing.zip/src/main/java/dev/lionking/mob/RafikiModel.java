package dev.lionking.mob;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

// Modell automatisch aus dem alten 1.4.2-Modell (LKModelRafiki) uebernommen.
public class RafikiModel extends EntityModel<Mob> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "rafiki"), "main");
	private final ModelPart root;
	private final ModelPart body;
	private final ModelPart rightarm;
	private final ModelPart leftarm;
	private final ModelPart rightleg;
	private final ModelPart leftleg;
	private final ModelPart tail1;
	private final ModelPart tail2;
	private final ModelPart tail3;
	private final ModelPart tail4;
	private final ModelPart head;

	public RafikiModel(ModelPart root) {
		this.root = root;
		this.body = root.getChild("body");
		this.rightarm = root.getChild("rightarm");
		this.leftarm = root.getChild("leftarm");
		this.rightleg = root.getChild("rightleg");
		this.leftleg = root.getChild("leftleg");
		this.tail1 = root.getChild("tail1");
		this.tail2 = root.getChild("tail2");
		this.tail3 = root.getChild("tail3");
		this.tail4 = root.getChild("tail4");
		this.head = root.getChild("head");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(16, 16).addBox(0.0F, 0.0F, 0.0F, 8.0F, 12.0F, 4.0F), PartPose.offset(-4.0F, 1.0F, -2.825F));
		root.addOrReplaceChild("rightarm", CubeListBuilder.create().texOffs(40, 17).addBox(0.0F, 0.0F, 0.0F, 3.0F, 11.0F, 3.0F), PartPose.offset(-7.0F, 2.0F, -1.5F));
		root.addOrReplaceChild("leftarm", CubeListBuilder.create().texOffs(40, 17).addBox(0.0F, 0.0F, 0.0F, 3.0F, 11.0F, 3.0F), PartPose.offset(4.0F, 2.0F, -1.5F));
		root.addOrReplaceChild("rightleg", CubeListBuilder.create().texOffs(0, 16).addBox(0.0F, 0.0F, 0.0F, 4.0F, 13.0F, 4.0F), PartPose.offset(-4.1F, 11.0F, 0.0F));
		root.addOrReplaceChild("leftleg", CubeListBuilder.create().texOffs(0, 16).addBox(0.0F, 0.0F, 0.0F, 4.0F, 13.0F, 4.0F), PartPose.offset(0.1F, 11.0F, 0.0F));
		root.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(0, 58).addBox(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 5.0F), PartPose.offset(-0.5F, 11.0F, 3.0F));
		root.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(12, 59).addBox(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 4.0F), PartPose.offset(-0.5F, 7.0F, 6.0F));
		root.addOrReplaceChild("tail3", CubeListBuilder.create().texOffs(22, 60).addBox(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 3.0F), PartPose.offset(-0.5F, 7.0F, 10.2F));
		root.addOrReplaceChild("tail4", CubeListBuilder.create().texOffs(30, 56).addBox(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 7.0F), PartPose.offset(-0.5F, 9.5F, 11.7F));
		root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-3.5F, -1.0F, -5.0F, 7.0F, 7.0F, 6.0F).texOffs(28, 0).addBox(-5.0F, -2.5F, -3.0F, 10.0F, 10.0F, 5.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
		return LayerDefinition.create(mesh, 64, 64);
	}

	@Override
	public void setupAnim(Mob entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.head.xRot = headPitch * Mth.DEG_TO_RAD;
		this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
		this.rightarm.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.leftarm.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.rightleg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.leftleg.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.tail1.yRot = Mth.cos(ageInTicks * 0.1F + 1.0F) * 0.1F;
		this.tail2.yRot = Mth.cos(ageInTicks * 0.1F + 2.0F) * 0.1F;
		this.tail3.yRot = Mth.cos(ageInTicks * 0.1F + 3.0F) * 0.1F;
		this.tail4.yRot = Mth.cos(ageInTicks * 0.1F + 4.0F) * 0.1F;
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
		root.render(poseStack, buffer, packedLight, packedOverlay, color);
	}
}
