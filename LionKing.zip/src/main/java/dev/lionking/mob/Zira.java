package dev.lionking.mob;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class Zira extends LKFighter {
	public Zira(EntityType<? extends Zira> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder attrs() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 300.0F)
				.add(Attributes.MOVEMENT_SPEED, 0.35F)
				.add(Attributes.ATTACK_DAMAGE, 5.0F)
				.add(Attributes.FOLLOW_RANGE, 24.0D);
	}

	@Override
	protected boolean hostileToPlayers() { return true; }

	@Override
	protected boolean persistent() { return true; }
}
