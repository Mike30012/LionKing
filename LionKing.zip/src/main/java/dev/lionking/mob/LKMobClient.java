package dev.lionking.mob;

import dev.lionking.LionKingMod;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = LionKingMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class LKMobClient {
	@SubscribeEvent
	public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(HyenaModel.LAYER, HyenaModel::createLayer);
		event.registerLayerDefinition(CrocodileModel.LAYER, CrocodileModel::createLayer);
		event.registerLayerDefinition(VultureModel.LAYER, VultureModel::createLayer);
		event.registerLayerDefinition(LionModel.LAYER, LionModel::createLayer);
		event.registerLayerDefinition(LionessModel.LAYER, LionessModel::createLayer);
		event.registerLayerDefinition(ScarModel.LAYER, ScarModel::createLayer);
		event.registerLayerDefinition(ZiraModel.LAYER, ZiraModel::createLayer);
		event.registerLayerDefinition(SimbaModel.LAYER, SimbaModel::createLayer);
		event.registerLayerDefinition(RafikiModel.LAYER, RafikiModel::createLayer);
		event.registerLayerDefinition(TimonModel.LAYER, TimonModel::createLayer);
		event.registerLayerDefinition(PumbaaModel.LAYER, PumbaaModel::createLayer);
		event.registerLayerDefinition(ZazuModel.LAYER, ZazuModel::createLayer);
	}

	@SubscribeEvent
	public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(LKMobs.HYENA.get(), ctx -> new LKMobRenderer(ctx, new HyenaModel(ctx.bakeLayer(HyenaModel.LAYER)), "hyena", 0.5F));
		event.registerEntityRenderer(LKMobs.CROCODILE.get(), ctx -> new LKMobRenderer(ctx, new CrocodileModel(ctx.bakeLayer(CrocodileModel.LAYER)), "crocodile", 0.8F));
		event.registerEntityRenderer(LKMobs.VULTURE.get(), ctx -> new LKMobRenderer(ctx, new VultureModel(ctx.bakeLayer(VultureModel.LAYER)), "vulture", 0.5F));
		event.registerEntityRenderer(LKMobs.LION.get(), ctx -> new LKMobRenderer(ctx, new LionModel(ctx.bakeLayer(LionModel.LAYER)), "lion", 0.8F));
		event.registerEntityRenderer(LKMobs.LIONESS.get(), ctx -> new LKMobRenderer(ctx, new LionessModel(ctx.bakeLayer(LionessModel.LAYER)), "lioness", 0.8F));
		event.registerEntityRenderer(LKMobs.SCAR.get(), ctx -> new LKMobRenderer(ctx, new ScarModel(ctx.bakeLayer(ScarModel.LAYER)), "scar", 0.8F));
		event.registerEntityRenderer(LKMobs.ZIRA.get(), ctx -> new LKMobRenderer(ctx, new ZiraModel(ctx.bakeLayer(ZiraModel.LAYER)), "zira", 0.8F));
		event.registerEntityRenderer(LKMobs.SIMBA.get(), ctx -> new LKMobRenderer(ctx, new SimbaModel(ctx.bakeLayer(SimbaModel.LAYER)), "simba", 0.8F));
		event.registerEntityRenderer(LKMobs.RAFIKI.get(), ctx -> new LKMobRenderer(ctx, new RafikiModel(ctx.bakeLayer(RafikiModel.LAYER)), "rafiki", 0.5F));
		event.registerEntityRenderer(LKMobs.TIMON.get(), ctx -> new LKMobRenderer(ctx, new TimonModel(ctx.bakeLayer(TimonModel.LAYER)), "timon", 0.5F));
		event.registerEntityRenderer(LKMobs.PUMBAA.get(), ctx -> new LKMobRenderer(ctx, new PumbaaModel(ctx.bakeLayer(PumbaaModel.LAYER)), "pumbaa", 0.8F));
		event.registerEntityRenderer(LKMobs.ZAZU.get(), ctx -> new LKMobRenderer(ctx, new ZazuModel(ctx.bakeLayer(ZazuModel.LAYER)), "zazu", 0.5F));
	}
}
