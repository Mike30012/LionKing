package dev.lionking.mob;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.lionking.LionKingMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

// Modell automatisch aus dem alten 1.4.2-Modell (LKModelZazu) uebernommen.
public class ZazuModel extends EntityModel<Mob> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(LionKingMod.MODID, "zazu"), "main");
	private final ModelPart root;
	private final ModelPart head;
	private final ModelPart headwear;
	private final ModelPart bill;
	private final ModelPart body;
	private final ModelPart rightLeg;
	private final ModelPart leftLeg;
	private final ModelPart rightWing;
	private final ModelPart leftWing;
	private final ModelPart tail;

	public ZazuModel(ModelPart root) {
		this.root = root;
		this.head = root.getChild("head");
		this.headwear = root.getChild("headwear");
		this.bill = root.getChild("bill");
		this.body = root.getChild("body");
		this.rightLeg = root.getChild("rightLeg");
		this.leftLeg = root.getChild("leftLeg");
		this.rightWing = root.getChild("rightWing");
		this.leftWing = root.getChild("leftWing");
		this.tail = root.getChild("tail");
	}

	public static LayerDefinition createLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();
		root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -6.0F, -2.0F, 4.0F, 5.0F, 3.0F), PartPose.offset(0.0F, 16.0F, -4.0F));
		root.addOrReplaceChild("headwear", CubeListBuilder.create().texOffs(14, 0).addBox(-2.0F, -6.25F, -0.75F, 4.0F, 5.0F, 3.0F), PartPose.offset(0.0F, 16.0F, -4.0F));
		root.addOrReplaceChild("bill", CubeListBuilder.create().texOffs(46, 25).addBox(-2.0F, -4.0F, -7.0F, 4.0F, 2.0F, 5.0F), PartPose.offset(0.0F, 15.0F, -4.0F));
		root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 10).addBox(-3.0F, -4.0F, -3.0F, 5.0F, 7.0F, 5.0F), PartPose.offset(0.5F, 16.0F, 0.5F));
		root.addOrReplaceChild("rightLeg", CubeListBuilder.create().texOffs(26, 0).addBox(-1.0F, 0.0F, -3.0F, 3.0F, 5.0F, 3.0F), PartPose.offset(-2.0F, 19.0F, 1.0F));
		root.addOrReplaceChild("leftLeg", CubeListBuilder.create().texOffs(26, 0).addBox(-1.0F, 0.0F, -3.0F, 3.0F, 5.0F, 3.0F), PartPose.offset(1.0F, 19.0F, 1.0F));
		root.addOrReplaceChild("rightWing", CubeListBuilder.create().texOffs(24, 13).addBox(-0.5F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F), PartPose.offset(-3.0F, 15.0F, 0.0F));
		root.addOrReplaceChild("leftWing", CubeListBuilder.create().texOffs(24, 13).addBox(-0.5F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F), PartPose.offset(3.0F, 15.0F, 0.0F));
		root.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(44, 5).addBox(-2.0F, 3.0F, 0.0F, 4.0F, 9.0F, 1.0F), PartPose.offset(0.0F, 16.0F, 0.0F));
		return LayerDefinition.create(mesh, 64, 32);
	}

	@Override
	public void setupAnim(Mob entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.head.xRot = headPitch * Mth.DEG_TO_RAD;
		this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
		this.headwear.xRot = this.head.xRot;
		this.headwear.yRot = this.head.yRot;
		this.rightLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.leftLeg.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * limbSwingAmount;
		this.rightWing.zRot = -Mth.sin(ageInTicks * 0.3F) * 0.6F;
		this.leftWing.zRot = Mth.sin(ageInTicks * 0.3F) * 0.6F;
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
		root.render(poseStack, buffer, packedLight, packedOverlay, color);
	}
}
