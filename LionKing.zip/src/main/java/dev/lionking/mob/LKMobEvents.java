package dev.lionking.mob;

import dev.lionking.LionKingMod;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

@EventBusSubscriber(modid = LionKingMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class LKMobEvents {
	@SubscribeEvent
	public static void attributes(EntityAttributeCreationEvent event) {
		event.put(LKMobs.HYENA.get(), Hyena.attrs().build());
		event.put(LKMobs.CROCODILE.get(), Crocodile.attrs().build());
		event.put(LKMobs.VULTURE.get(), Vulture.attrs().build());
		event.put(LKMobs.LION.get(), Lion.attrs().build());
		event.put(LKMobs.LIONESS.get(), Lioness.attrs().build());
		event.put(LKMobs.SCAR.get(), Scar.attrs().build());
		event.put(LKMobs.ZIRA.get(), Zira.attrs().build());
		event.put(LKMobs.SIMBA.get(), Simba.attrs().build());
		event.put(LKMobs.RAFIKI.get(), Rafiki.attrs().build());
		event.put(LKMobs.TIMON.get(), Timon.attrs().build());
		event.put(LKMobs.PUMBAA.get(), Pumbaa.attrs().build());
		event.put(LKMobs.ZAZU.get(), Zazu.attrs().build());
	}

	@SubscribeEvent
	public static void spawnRules(RegisterSpawnPlacementsEvent event) {
		event.register(LKMobs.HYENA.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.CROCODILE.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.VULTURE.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.LION.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.LIONESS.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.SCAR.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.ZIRA.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.SIMBA.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.RAFIKI.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.TIMON.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.PUMBAA.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
		event.register(LKMobs.ZAZU.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (t, lvl, reason, pos, rnd) -> Mob.checkMobSpawnRules(t, lvl, reason, pos, rnd), RegisterSpawnPlacementsEvent.Operation.OR);
	}
}
