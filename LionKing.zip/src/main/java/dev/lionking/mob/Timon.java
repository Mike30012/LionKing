package dev.lionking.mob;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class Timon extends LKNpc {
	public Timon(EntityType<? extends Timon> type, Level level) {
		super(type, level);
	}

	public static AttributeSupplier.Builder attrs() {
		return Mob.createMobAttributes()
				.add(Attributes.MAX_HEALTH, 100.0F)
				.add(Attributes.MOVEMENT_SPEED, 0.22F);
	}

	private static final String[] LINES = {
			"§e<Pumbaa> §fI don't know. Do you think we can eat him?",
			"§e<Timon> §fOf course we can't eat him, you idiot. Lie down before you hurt yourself.",
			"§e<Timon> §fAlthough now that you mention it...",
			"§e<Pumbaa> §fKid, we're really hungry. Do you think you could find us something to eat?",
			"§e<Timon> §fPumbaa, that's an awful idea. It'll never work.",
			"§e<Timon> §fWait a minute. I've got a great idea! You! You there! Do you think you could find us something to eat?",
			"§e<Pumbaa> §fOur favourite food is bugs. Especially those stripy blue ones that hide under logs!"
	};

	@Override
	protected String[] lines() { return LINES; }
}
