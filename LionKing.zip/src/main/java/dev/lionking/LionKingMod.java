package dev.lionking;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.common.SimpleTier;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.TransparentBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** The Lion King Mod - privater Port auf NeoForge 1.21.1 (Etappe 1+2: einfache Items und Bloecke, Werkzeuge, Ruestung). */
@Mod(LionKingMod.MODID)
public class LionKingMod {
	public static final String MODID = "lionking";

	public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
	public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
	public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

	// ---- Items
	public static final DeferredItem<Item> HYENA_BONE = ITEMS.registerSimpleItem("hyena_bone", new Item.Properties());
	public static final DeferredItem<Item> LION_RAW = ITEMS.registerSimpleItem("lion_raw", new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3f).build()));
	public static final DeferredItem<Item> LION_COOKED = ITEMS.registerSimpleItem("lion_cooked", new Item.Properties().food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.8f).build()));
	public static final DeferredItem<Item> MANGO = ITEMS.registerSimpleItem("mango", new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3f).build()));
	public static final DeferredItem<Item> FEATHER_BLUE = ITEMS.registerSimpleItem("feather_blue", new Item.Properties());
	public static final DeferredItem<Item> FEATHER_YELLOW = ITEMS.registerSimpleItem("feather_yellow", new Item.Properties());
	public static final DeferredItem<Item> FEATHER_RED = ITEMS.registerSimpleItem("feather_red", new Item.Properties());
	public static final DeferredItem<Item> DART_BLUE = ITEMS.registerSimpleItem("dart_blue", new Item.Properties());
	public static final DeferredItem<Item> DART_YELLOW = ITEMS.registerSimpleItem("dart_yellow", new Item.Properties());
	public static final DeferredItem<Item> DART_RED = ITEMS.registerSimpleItem("dart_red", new Item.Properties());
	public static final DeferredItem<Item> HYENA_BONE_SHARD = ITEMS.registerSimpleItem("hyena_bone_shard", new Item.Properties());
	public static final DeferredItem<Item> ZEBRA_HIDE = ITEMS.registerSimpleItem("zebra_hide", new Item.Properties());
	public static final DeferredItem<Item> MANGO_DUST = ITEMS.registerSimpleItem("mango_dust", new Item.Properties());
	public static final DeferredItem<Item> DART_BLACK = ITEMS.registerSimpleItem("dart_black", new Item.Properties());
	public static final DeferredItem<Item> FEATHER_BLACK = ITEMS.registerSimpleItem("feather_black", new Item.Properties());
	public static final DeferredItem<Item> SILVER = ITEMS.registerSimpleItem("silver", new Item.Properties());
	public static final DeferredItem<Item> TERMITE_DUST = ITEMS.registerSimpleItem("termite_dust", new Item.Properties());
	public static final DeferredItem<Item> CRYSTAL = ITEMS.registerSimpleItem("crystal", new Item.Properties());
	public static final DeferredItem<Item> BUG = ITEMS.registerSimpleItem("bug", new Item.Properties());
	public static final DeferredItem<Item> CHOCOLATE_MUFASA = ITEMS.registerSimpleItem("chocolate_mufasa", new Item.Properties().food(new FoodProperties.Builder().nutrition(16).saturationModifier(0.8f).build()));
	public static final DeferredItem<Item> FUR = ITEMS.registerSimpleItem("fur", new Item.Properties());
	public static final DeferredItem<Item> ZEBRA_RAW = ITEMS.registerSimpleItem("zebra_raw", new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.1f).build()));
	public static final DeferredItem<Item> ZEBRA_COOKED = ITEMS.registerSimpleItem("zebra_cooked", new Item.Properties().food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.4f).build()));
	public static final DeferredItem<Item> RHINO_RAW = ITEMS.registerSimpleItem("rhino_raw", new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.1f).build()));
	public static final DeferredItem<Item> RHINO_COOKED = ITEMS.registerSimpleItem("rhino_cooked", new Item.Properties().food(new FoodProperties.Builder().nutrition(7).saturationModifier(0.4f).build()));
	public static final DeferredItem<Item> HORN = ITEMS.registerSimpleItem("horn", new Item.Properties());
	public static final DeferredItem<Item> GEMSBOK_HIDE = ITEMS.registerSimpleItem("gemsbok_hide", new Item.Properties());
	public static final DeferredItem<Item> GEMSBOK_HORN = ITEMS.registerSimpleItem("gemsbok_horn", new Item.Properties());
	public static final DeferredItem<Item> PEACOCK_GEM = ITEMS.registerSimpleItem("peacock_gem", new Item.Properties());
	public static final DeferredItem<Item> CORN = ITEMS.registerSimpleItem("corn", new Item.Properties().food(new FoodProperties.Builder().nutrition(1).saturationModifier(0.1f).build()));
	public static final DeferredItem<Item> POPCORN = ITEMS.registerSimpleItem("popcorn", new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.4f).build()));
	public static final DeferredItem<Item> NUKA_SHARD = ITEMS.registerSimpleItem("nuka_shard", new Item.Properties());
	public static final DeferredItem<Item> OUTLANDER_FUR = ITEMS.registerSimpleItem("outlander_fur", new Item.Properties());
	public static final DeferredItem<Item> OUTLANDER_MEAT = ITEMS.registerSimpleItem("outlander_meat", new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.2f).build()));
	public static final DeferredItem<Item> KIVULITE = ITEMS.registerSimpleItem("kivulite", new Item.Properties());
	public static final DeferredItem<Item> CROCODILE_MEAT = ITEMS.registerSimpleItem("crocodile_meat", new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.4f).build()));
	public static final DeferredItem<Item> POISON = ITEMS.registerSimpleItem("poison", new Item.Properties());
	public static final DeferredItem<Item> KIWANO = ITEMS.registerSimpleItem("kiwano", new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.3f).build()));

	// ---- Bloecke
	public static final DeferredBlock<Block> PRIDESTONE = BLOCKS.registerSimpleBlock("pridestone", BlockBehaviour.Properties.of().strength(1.5f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> PRIDESTONE_ITEM = ITEMS.registerSimpleBlockItem("pridestone", PRIDESTONE);
	public static final DeferredBlock<Block> PRIDE_COAL = BLOCKS.registerSimpleBlock("pride_coal", BlockBehaviour.Properties.of().strength(3.0f, 5.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> PRIDE_COAL_ITEM = ITEMS.registerSimpleBlockItem("pride_coal", PRIDE_COAL);
	public static final DeferredBlock<Block> PRIDE_BRICK = BLOCKS.registerSimpleBlock("pride_brick", BlockBehaviour.Properties.of().strength(1.5f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> PRIDE_BRICK_ITEM = ITEMS.registerSimpleBlockItem("pride_brick", PRIDE_BRICK);
	public static final DeferredBlock<Block> TERMITE = BLOCKS.registerSimpleBlock("termite", BlockBehaviour.Properties.of().strength(0.5f, 3.0f).sound(SoundType.SAND));
	public static final DeferredItem<BlockItem> TERMITE_ITEM = ITEMS.registerSimpleBlockItem("termite", TERMITE);
	public static final DeferredBlock<Block> PRIDE_BRICK_MOSSY = BLOCKS.registerSimpleBlock("pride_brick_mossy", BlockBehaviour.Properties.of().strength(1.5f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> PRIDE_BRICK_MOSSY_ITEM = ITEMS.registerSimpleBlockItem("pride_brick_mossy", PRIDE_BRICK_MOSSY);
	public static final DeferredBlock<Block> ORE_SILVER = BLOCKS.registerSimpleBlock("ore_silver", BlockBehaviour.Properties.of().strength(3.0f, 5.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> ORE_SILVER_ITEM = ITEMS.registerSimpleBlockItem("ore_silver", ORE_SILVER);
	public static final DeferredBlock<Block> OUTSAND = BLOCKS.registerSimpleBlock("outsand", BlockBehaviour.Properties.of().strength(0.7f).sound(SoundType.SAND));
	public static final DeferredItem<BlockItem> OUTSAND_ITEM = ITEMS.registerSimpleBlockItem("outsand", OUTSAND);
	public static final DeferredBlock<Block> OUTGLASS = BLOCKS.registerBlock("outglass", TransparentBlock::new, BlockBehaviour.Properties.of().strength(0.4f).noOcclusion().sound(SoundType.GLASS));
	public static final DeferredItem<BlockItem> OUTGLASS_ITEM = ITEMS.registerSimpleBlockItem("outglass", OUTGLASS);
	public static final DeferredBlock<Block> ORE_PEACOCK = BLOCKS.registerSimpleBlock("ore_peacock", BlockBehaviour.Properties.of().strength(3.0f, 5.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> ORE_PEACOCK_ITEM = ITEMS.registerSimpleBlockItem("ore_peacock", ORE_PEACOCK);
	public static final DeferredBlock<Block> BLOCK_SILVER = BLOCKS.registerSimpleBlock("block_silver", BlockBehaviour.Properties.of().strength(5.0f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> BLOCK_SILVER_ITEM = ITEMS.registerSimpleBlockItem("block_silver", BLOCK_SILVER);
	public static final DeferredBlock<Block> BLOCK_PEACOCK = BLOCKS.registerSimpleBlock("block_peacock", BlockBehaviour.Properties.of().strength(5.0f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> BLOCK_PEACOCK_ITEM = ITEMS.registerSimpleBlockItem("block_peacock", BLOCK_PEACOCK);

	// ---- Werkzeuge
	public static final Tier TIER_PRIDESTONE = new SimpleTier(BlockTags.INCORRECT_FOR_STONE_TOOL, 150, 4.0f, 1.0f, 5, () -> Ingredient.of(PRIDESTONE_ITEM.get()));
	public static final Tier TIER_SILVER = new SimpleTier(BlockTags.INCORRECT_FOR_IRON_TOOL, 480, 6.0f, 2.0f, 16, () -> Ingredient.of(SILVER.get()));
	public static final Tier TIER_PEACOCK = new SimpleTier(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1475, 8.0f, 3.0f, 9, () -> Ingredient.of(PEACOCK_GEM.get()));
	public static final Tier TIER_KIVULITE = new SimpleTier(BlockTags.INCORRECT_FOR_IRON_TOOL, 70, 6.0f, 0.0f, 3, () -> Ingredient.of(KIVULITE.get()));
	public static final Tier TIER_CORRUPT = new SimpleTier(BlockTags.INCORRECT_FOR_STONE_TOOL, 120, 5.5f, 1.0f, 7, () -> Ingredient.of(PRIDESTONE_ITEM.get()));
	public static final DeferredItem<Item> SHOVEL_PRIDESTONE = ITEMS.register("shovel_pridestone", () -> new ShovelItem(TIER_PRIDESTONE, new Item.Properties().attributes(ShovelItem.createAttributes(TIER_PRIDESTONE, 1.5f, -3.0f))));
	public static final DeferredItem<Item> PICKAXE_PRIDESTONE = ITEMS.register("pickaxe_pridestone", () -> new PickaxeItem(TIER_PRIDESTONE, new Item.Properties().attributes(PickaxeItem.createAttributes(TIER_PRIDESTONE, 1.0f, -2.8f))));
	public static final DeferredItem<Item> AXE_PRIDESTONE = ITEMS.register("axe_pridestone", () -> new AxeItem(TIER_PRIDESTONE, new Item.Properties().attributes(AxeItem.createAttributes(TIER_PRIDESTONE, 6.0f, -3.1f))));
	public static final DeferredItem<Item> SWORD_PRIDESTONE = ITEMS.register("sword_pridestone", () -> new SwordItem(TIER_PRIDESTONE, new Item.Properties().attributes(SwordItem.createAttributes(TIER_PRIDESTONE, 3, -2.4f))));
	public static final DeferredItem<Item> HOE_PRIDESTONE = ITEMS.register("hoe_pridestone", () -> new HoeItem(TIER_PRIDESTONE, new Item.Properties().attributes(HoeItem.createAttributes(TIER_PRIDESTONE, -2.0f, -1.0f))));
	public static final DeferredItem<Item> SHOVEL_SILVER = ITEMS.register("shovel_silver", () -> new ShovelItem(TIER_SILVER, new Item.Properties().attributes(ShovelItem.createAttributes(TIER_SILVER, 1.5f, -3.0f))));
	public static final DeferredItem<Item> PICKAXE_SILVER = ITEMS.register("pickaxe_silver", () -> new PickaxeItem(TIER_SILVER, new Item.Properties().attributes(PickaxeItem.createAttributes(TIER_SILVER, 1.0f, -2.8f))));
	public static final DeferredItem<Item> AXE_SILVER = ITEMS.register("axe_silver", () -> new AxeItem(TIER_SILVER, new Item.Properties().attributes(AxeItem.createAttributes(TIER_SILVER, 6.0f, -3.1f))));
	public static final DeferredItem<Item> SWORD_SILVER = ITEMS.register("sword_silver", () -> new SwordItem(TIER_SILVER, new Item.Properties().attributes(SwordItem.createAttributes(TIER_SILVER, 3, -2.4f))));
	public static final DeferredItem<Item> HOE_SILVER = ITEMS.register("hoe_silver", () -> new HoeItem(TIER_SILVER, new Item.Properties().attributes(HoeItem.createAttributes(TIER_SILVER, -2.0f, -1.0f))));
	public static final DeferredItem<Item> SHOVEL_PEACOCK = ITEMS.register("shovel_peacock", () -> new ShovelItem(TIER_PEACOCK, new Item.Properties().attributes(ShovelItem.createAttributes(TIER_PEACOCK, 1.5f, -3.0f))));
	public static final DeferredItem<Item> PICKAXE_PEACOCK = ITEMS.register("pickaxe_peacock", () -> new PickaxeItem(TIER_PEACOCK, new Item.Properties().attributes(PickaxeItem.createAttributes(TIER_PEACOCK, 1.0f, -2.8f))));
	public static final DeferredItem<Item> AXE_PEACOCK = ITEMS.register("axe_peacock", () -> new AxeItem(TIER_PEACOCK, new Item.Properties().attributes(AxeItem.createAttributes(TIER_PEACOCK, 6.0f, -3.1f))));
	public static final DeferredItem<Item> SWORD_PEACOCK = ITEMS.register("sword_peacock", () -> new SwordItem(TIER_PEACOCK, new Item.Properties().attributes(SwordItem.createAttributes(TIER_PEACOCK, 3, -2.4f))));
	public static final DeferredItem<Item> HOE_PEACOCK = ITEMS.register("hoe_peacock", () -> new HoeItem(TIER_PEACOCK, new Item.Properties().attributes(HoeItem.createAttributes(TIER_PEACOCK, -2.0f, -1.0f))));
	public static final DeferredItem<Item> SHOVEL_KIVULITE = ITEMS.register("shovel_kivulite", () -> new ShovelItem(TIER_KIVULITE, new Item.Properties().attributes(ShovelItem.createAttributes(TIER_KIVULITE, 1.5f, -3.0f))));
	public static final DeferredItem<Item> PICKAXE_KIVULITE = ITEMS.register("pickaxe_kivulite", () -> new PickaxeItem(TIER_KIVULITE, new Item.Properties().attributes(PickaxeItem.createAttributes(TIER_KIVULITE, 1.0f, -2.8f))));
	public static final DeferredItem<Item> AXE_KIVULITE = ITEMS.register("axe_kivulite", () -> new AxeItem(TIER_KIVULITE, new Item.Properties().attributes(AxeItem.createAttributes(TIER_KIVULITE, 6.0f, -3.1f))));
	public static final DeferredItem<Item> SWORD_KIVULITE = ITEMS.register("sword_kivulite", () -> new SwordItem(TIER_KIVULITE, new Item.Properties().attributes(SwordItem.createAttributes(TIER_KIVULITE, 3, -2.4f))));
	public static final DeferredItem<Item> SHOVEL_CORRUPT = ITEMS.register("shovel_corrupt", () -> new ShovelItem(TIER_CORRUPT, new Item.Properties().attributes(ShovelItem.createAttributes(TIER_CORRUPT, 1.5f, -3.0f))));
	public static final DeferredItem<Item> PICKAXE_CORRUPT = ITEMS.register("pickaxe_corrupt", () -> new PickaxeItem(TIER_CORRUPT, new Item.Properties().attributes(PickaxeItem.createAttributes(TIER_CORRUPT, 1.0f, -2.8f))));
	public static final DeferredItem<Item> AXE_CORRUPT = ITEMS.register("axe_corrupt", () -> new AxeItem(TIER_CORRUPT, new Item.Properties().attributes(AxeItem.createAttributes(TIER_CORRUPT, 6.0f, -3.1f))));
	public static final DeferredItem<Item> SWORD_CORRUPT = ITEMS.register("sword_corrupt", () -> new SwordItem(TIER_CORRUPT, new Item.Properties().attributes(SwordItem.createAttributes(TIER_CORRUPT, 3, -2.4f))));

	// ---- Ruestung
	public static final DeferredRegister<ArmorMaterial> ARMOR = DeferredRegister.create(Registries.ARMOR_MATERIAL, MODID);

	private static Map<ArmorItem.Type, Integer> defense(int helmet, int chest, int legs, int boots) {
		EnumMap<ArmorItem.Type, Integer> m = new EnumMap<>(ArmorItem.Type.class);
		m.put(ArmorItem.Type.HELMET, helmet);
		m.put(ArmorItem.Type.CHESTPLATE, chest);
		m.put(ArmorItem.Type.LEGGINGS, legs);
		m.put(ArmorItem.Type.BOOTS, boots);
		m.put(ArmorItem.Type.BODY, chest);
		return m;
	}

	public static final DeferredHolder<ArmorMaterial, ArmorMaterial> ARMOR_GEMSBOK = ARMOR.register("gemsbok", () -> new ArmorMaterial(defense(2, 5, 4, 1), 8, SoundEvents.ARMOR_EQUIP_IRON, () -> Ingredient.of(GEMSBOK_HIDE.get()), List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(MODID, "gemsbok"))), 0.0f, 0.0f));
	public static final DeferredHolder<ArmorMaterial, ArmorMaterial> ARMOR_SILVER = ARMOR.register("silver", () -> new ArmorMaterial(defense(2, 7, 5, 2), 16, SoundEvents.ARMOR_EQUIP_IRON, () -> Ingredient.of(SILVER.get()), List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(MODID, "silver"))), 0.0f, 0.0f));
	public static final DeferredHolder<ArmorMaterial, ArmorMaterial> ARMOR_PEACOCK = ARMOR.register("peacock", () -> new ArmorMaterial(defense(3, 8, 6, 3), 9, SoundEvents.ARMOR_EQUIP_IRON, () -> Ingredient.of(PEACOCK_GEM.get()), List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(MODID, "peacock"))), 0.0f, 0.0f));
	public static final DeferredItem<Item> HELMET_SILVER = ITEMS.register("helmet_silver", () -> new ArmorItem(ARMOR_SILVER, ArmorItem.Type.HELMET, new Item.Properties().durability(209)));
	public static final DeferredItem<Item> BODY_SILVER = ITEMS.register("body_silver", () -> new ArmorItem(ARMOR_SILVER, ArmorItem.Type.CHESTPLATE, new Item.Properties().durability(304)));
	public static final DeferredItem<Item> LEGS_SILVER = ITEMS.register("legs_silver", () -> new ArmorItem(ARMOR_SILVER, ArmorItem.Type.LEGGINGS, new Item.Properties().durability(285)));
	public static final DeferredItem<Item> BOOTS_SILVER = ITEMS.register("boots_silver", () -> new ArmorItem(ARMOR_SILVER, ArmorItem.Type.BOOTS, new Item.Properties().durability(247)));
	public static final DeferredItem<Item> HELMET_GEMSBOK = ITEMS.register("helmet_gemsbok", () -> new ArmorItem(ARMOR_GEMSBOK, ArmorItem.Type.HELMET, new Item.Properties().durability(88)));
	public static final DeferredItem<Item> BODY_GEMSBOK = ITEMS.register("body_gemsbok", () -> new ArmorItem(ARMOR_GEMSBOK, ArmorItem.Type.CHESTPLATE, new Item.Properties().durability(128)));
	public static final DeferredItem<Item> LEGS_GEMSBOK = ITEMS.register("legs_gemsbok", () -> new ArmorItem(ARMOR_GEMSBOK, ArmorItem.Type.LEGGINGS, new Item.Properties().durability(120)));
	public static final DeferredItem<Item> BOOTS_GEMSBOK = ITEMS.register("boots_gemsbok", () -> new ArmorItem(ARMOR_GEMSBOK, ArmorItem.Type.BOOTS, new Item.Properties().durability(104)));
	public static final DeferredItem<Item> HELMET_PEACOCK = ITEMS.register("helmet_peacock", () -> new ArmorItem(ARMOR_PEACOCK, ArmorItem.Type.HELMET, new Item.Properties().durability(341)));
	public static final DeferredItem<Item> BODY_PEACOCK = ITEMS.register("body_peacock", () -> new ArmorItem(ARMOR_PEACOCK, ArmorItem.Type.CHESTPLATE, new Item.Properties().durability(496)));
	public static final DeferredItem<Item> LEGS_PEACOCK = ITEMS.register("legs_peacock", () -> new ArmorItem(ARMOR_PEACOCK, ArmorItem.Type.LEGGINGS, new Item.Properties().durability(465)));
	public static final DeferredItem<Item> BOOTS_PEACOCK = ITEMS.register("boots_peacock", () -> new ArmorItem(ARMOR_PEACOCK, ArmorItem.Type.BOOTS, new Item.Properties().durability(403)));

	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("lionking", () -> CreativeModeTab.builder()
			.title(Component.literal("The Lion King"))
			.icon(() -> new ItemStack(SILVER.get()))
			.displayItems((params, out) -> ITEMS.getEntries().forEach(e -> out.accept(e.get())))
			.build());

	public LionKingMod(IEventBus modBus) {
		ITEMS.register(modBus);
		BLOCKS.register(modBus);
		ARMOR.register(modBus);
		TABS.register(modBus);
	}
}
