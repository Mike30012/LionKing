package dev.lionking;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.TransparentBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** The Lion King Mod - privater Port auf NeoForge 1.21.1 (Etappe 1: einfache Items und Bloecke). */
@Mod(LionKingMod.MODID)
public class LionKingMod {
	public static final String MODID = "lionking";

	public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
	public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
	public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

	// ---- Items
	public static final DeferredItem<Item> HYENA_BONE = ITEMS.registerSimpleItem("hyena_bone", new Item.Properties());
	public static final DeferredItem<Item> LION_RAW = ITEMS.registerSimpleItem("lion_raw", new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3f).build()));
	public static final DeferredItem<Item> LION_COOKED = ITEMS.registerSimpleItem("lion_cooked", new Item.Properties().food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.8f).build()));
	public static final DeferredItem<Item> MANGO = ITEMS.registerSimpleItem("mango", new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3f).build()));
	public static final DeferredItem<Item> FEATHER_BLUE = ITEMS.registerSimpleItem("feather_blue", new Item.Properties());
	public static final DeferredItem<Item> FEATHER_YELLOW = ITEMS.registerSimpleItem("feather_yellow", new Item.Properties());
	public static final DeferredItem<Item> FEATHER_RED = ITEMS.registerSimpleItem("feather_red", new Item.Properties());
	public static final DeferredItem<Item> DART_BLUE = ITEMS.registerSimpleItem("dart_blue", new Item.Properties());
	public static final DeferredItem<Item> DART_YELLOW = ITEMS.registerSimpleItem("dart_yellow", new Item.Properties());
	public static final DeferredItem<Item> DART_RED = ITEMS.registerSimpleItem("dart_red", new Item.Properties());
	public static final DeferredItem<Item> HYENA_BONE_SHARD = ITEMS.registerSimpleItem("hyena_bone_shard", new Item.Properties());
	public static final DeferredItem<Item> ZEBRA_HIDE = ITEMS.registerSimpleItem("zebra_hide", new Item.Properties());
	public static final DeferredItem<Item> MANGO_DUST = ITEMS.registerSimpleItem("mango_dust", new Item.Properties());
	public static final DeferredItem<Item> DART_BLACK = ITEMS.registerSimpleItem("dart_black", new Item.Properties());
	public static final DeferredItem<Item> FEATHER_BLACK = ITEMS.registerSimpleItem("feather_black", new Item.Properties());
	public static final DeferredItem<Item> SILVER = ITEMS.registerSimpleItem("silver", new Item.Properties());
	public static final DeferredItem<Item> TERMITE_DUST = ITEMS.registerSimpleItem("termite_dust", new Item.Properties());
	public static final DeferredItem<Item> CRYSTAL = ITEMS.registerSimpleItem("crystal", new Item.Properties());
	public static final DeferredItem<Item> BUG = ITEMS.registerSimpleItem("bug", new Item.Properties());
	public static final DeferredItem<Item> CHOCOLATE_MUFASA = ITEMS.registerSimpleItem("chocolate_mufasa", new Item.Properties().food(new FoodProperties.Builder().nutrition(16).saturationModifier(0.8f).build()));
	public static final DeferredItem<Item> FUR = ITEMS.registerSimpleItem("fur", new Item.Properties());
	public static final DeferredItem<Item> ZEBRA_RAW = ITEMS.registerSimpleItem("zebra_raw", new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.1f).build()));
	public static final DeferredItem<Item> ZEBRA_COOKED = ITEMS.registerSimpleItem("zebra_cooked", new Item.Properties().food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.4f).build()));
	public static final DeferredItem<Item> RHINO_RAW = ITEMS.registerSimpleItem("rhino_raw", new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.1f).build()));
	public static final DeferredItem<Item> RHINO_COOKED = ITEMS.registerSimpleItem("rhino_cooked", new Item.Properties().food(new FoodProperties.Builder().nutrition(7).saturationModifier(0.4f).build()));
	public static final DeferredItem<Item> HORN = ITEMS.registerSimpleItem("horn", new Item.Properties());
	public static final DeferredItem<Item> GEMSBOK_HIDE = ITEMS.registerSimpleItem("gemsbok_hide", new Item.Properties());
	public static final DeferredItem<Item> GEMSBOK_HORN = ITEMS.registerSimpleItem("gemsbok_horn", new Item.Properties());
	public static final DeferredItem<Item> PEACOCK_GEM = ITEMS.registerSimpleItem("peacock_gem", new Item.Properties());
	public static final DeferredItem<Item> CORN = ITEMS.registerSimpleItem("corn", new Item.Properties().food(new FoodProperties.Builder().nutrition(1).saturationModifier(0.1f).build()));
	public static final DeferredItem<Item> POPCORN = ITEMS.registerSimpleItem("popcorn", new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.4f).build()));
	public static final DeferredItem<Item> NUKA_SHARD = ITEMS.registerSimpleItem("nuka_shard", new Item.Properties());
	public static final DeferredItem<Item> OUTLANDER_FUR = ITEMS.registerSimpleItem("outlander_fur", new Item.Properties());
	public static final DeferredItem<Item> OUTLANDER_MEAT = ITEMS.registerSimpleItem("outlander_meat", new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.2f).build()));
	public static final DeferredItem<Item> KIVULITE = ITEMS.registerSimpleItem("kivulite", new Item.Properties());
	public static final DeferredItem<Item> CROCODILE_MEAT = ITEMS.registerSimpleItem("crocodile_meat", new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.4f).build()));
	public static final DeferredItem<Item> POISON = ITEMS.registerSimpleItem("poison", new Item.Properties());
	public static final DeferredItem<Item> KIWANO = ITEMS.registerSimpleItem("kiwano", new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.3f).build()));

	// ---- Bloecke
	public static final DeferredBlock<Block> PRIDESTONE = BLOCKS.registerSimpleBlock("pridestone", BlockBehaviour.Properties.of().strength(1.5f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> PRIDESTONE_ITEM = ITEMS.registerSimpleBlockItem("pridestone", PRIDESTONE);
	public static final DeferredBlock<Block> PRIDE_COAL = BLOCKS.registerSimpleBlock("pride_coal", BlockBehaviour.Properties.of().strength(3.0f, 5.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> PRIDE_COAL_ITEM = ITEMS.registerSimpleBlockItem("pride_coal", PRIDE_COAL);
	public static final DeferredBlock<Block> PRIDE_BRICK = BLOCKS.registerSimpleBlock("pride_brick", BlockBehaviour.Properties.of().strength(1.5f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> PRIDE_BRICK_ITEM = ITEMS.registerSimpleBlockItem("pride_brick", PRIDE_BRICK);
	public static final DeferredBlock<Block> TERMITE = BLOCKS.registerSimpleBlock("termite", BlockBehaviour.Properties.of().strength(0.5f, 3.0f).sound(SoundType.SAND));
	public static final DeferredItem<BlockItem> TERMITE_ITEM = ITEMS.registerSimpleBlockItem("termite", TERMITE);
	public static final DeferredBlock<Block> PRIDE_BRICK_MOSSY = BLOCKS.registerSimpleBlock("pride_brick_mossy", BlockBehaviour.Properties.of().strength(1.5f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> PRIDE_BRICK_MOSSY_ITEM = ITEMS.registerSimpleBlockItem("pride_brick_mossy", PRIDE_BRICK_MOSSY);
	public static final DeferredBlock<Block> ORE_SILVER = BLOCKS.registerSimpleBlock("ore_silver", BlockBehaviour.Properties.of().strength(3.0f, 5.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> ORE_SILVER_ITEM = ITEMS.registerSimpleBlockItem("ore_silver", ORE_SILVER);
	public static final DeferredBlock<Block> OUTSAND = BLOCKS.registerSimpleBlock("outsand", BlockBehaviour.Properties.of().strength(0.7f).sound(SoundType.SAND));
	public static final DeferredItem<BlockItem> OUTSAND_ITEM = ITEMS.registerSimpleBlockItem("outsand", OUTSAND);
	public static final DeferredBlock<Block> OUTGLASS = BLOCKS.registerBlock("outglass", TransparentBlock::new, BlockBehaviour.Properties.of().strength(0.4f).noOcclusion().sound(SoundType.GLASS));
	public static final DeferredItem<BlockItem> OUTGLASS_ITEM = ITEMS.registerSimpleBlockItem("outglass", OUTGLASS);
	public static final DeferredBlock<Block> ORE_PEACOCK = BLOCKS.registerSimpleBlock("ore_peacock", BlockBehaviour.Properties.of().strength(3.0f, 5.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> ORE_PEACOCK_ITEM = ITEMS.registerSimpleBlockItem("ore_peacock", ORE_PEACOCK);
	public static final DeferredBlock<Block> BLOCK_SILVER = BLOCKS.registerSimpleBlock("block_silver", BlockBehaviour.Properties.of().strength(5.0f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> BLOCK_SILVER_ITEM = ITEMS.registerSimpleBlockItem("block_silver", BLOCK_SILVER);
	public static final DeferredBlock<Block> BLOCK_PEACOCK = BLOCKS.registerSimpleBlock("block_peacock", BlockBehaviour.Properties.of().strength(5.0f, 10.0f).requiresCorrectToolForDrops());
	public static final DeferredItem<BlockItem> BLOCK_PEACOCK_ITEM = ITEMS.registerSimpleBlockItem("block_peacock", BLOCK_PEACOCK);

	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("lionking", () -> CreativeModeTab.builder()
			.title(Component.literal("The Lion King"))
			.icon(() -> new ItemStack(SILVER.get()))
			.displayItems((params, out) -> ITEMS.getEntries().forEach(e -> out.accept(e.get())))
			.build());

	public LionKingMod(IEventBus modBus) {
		ITEMS.register(modBus);
		BLOCKS.register(modBus);
		TABS.register(modBus);
	}
}
